#!/bin/bash

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"

ESPEAK="$SCRIPT_DIR/bin/espeak-ng"
APLAY="$SCRIPT_DIR/bin/aplay"
DATA="$SCRIPT_DIR/share/espeak-ng-data"
LIB="$SCRIPT_DIR/lib"
WAV="$SCRIPT_DIR/speech.wav"

if [ $# -eq 0 ]; then
    echo "Usage:"
    echo "  $0 \"Κείμενο\""
    echo "  $0 -v el \"Ελληνικά\""
    echo "  $0 -v en \"English\""
    exit 1
fi

if [ ! -x "$ESPEAK" ]; then
    echo "ERROR: eSpeak NG not found:"
    echo "$ESPEAK"
    exit 1
fi

if [ ! -d "$DATA" ]; then
    echo "ERROR: eSpeak NG data not found:"
    echo "$DATA"
    exit 1
fi

# Ελληνικά ως προεπιλογή
if [ "$1" != "-v" ]; then
    set -- -v el "$@"
fi

echo "Generating: $WAV"

ESPEAK_DATA_PATH="$DATA" \
"$ESPEAK" "$@" -w "$WAV"

if [ ! -s "$WAV" ]; then
    echo "ERROR: Failed to create WAV."
    exit 1
fi

echo "Created: $WAV"

if [ -x "$APLAY" ]; then
    LD_LIBRARY_PATH="$LIB${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
    "$APLAY" "$WAV"
else
    echo
    echo "aplay not found."
    echo "WAV is available at:"
    echo "$WAV"
fi
